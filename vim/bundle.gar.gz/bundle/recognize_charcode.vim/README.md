 * mirror from http://d.hatena.ne.jp/shizu9/20090402/1238697718
